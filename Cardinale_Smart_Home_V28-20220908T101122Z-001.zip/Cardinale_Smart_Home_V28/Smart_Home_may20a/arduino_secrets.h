#define SECRET_SSID "C-4628519"
#define SECRET_PASS "!UMB_3473885391!"

#define SECRET_SSID1 "TIM-42993301"
#define SECRET_PASS1 "pACeUsX3cuzkJ9vZ"

#define SECRET_SSID2 "iPhone del Cardi"
#define SECRET_PASS2 "provapass"

#define SECRET_SSID3 "ArcobalenoCompleto"
#define SECRET_PASS3 "ArcobalenoCompleto"

#define SECRET_SSID4 "Lori's phone"
#define SECRET_PASS4 "albergo71"

#define SECRET_SSID5 "ESAME"
#define SECRET_PASS5 "Giugno2022"
